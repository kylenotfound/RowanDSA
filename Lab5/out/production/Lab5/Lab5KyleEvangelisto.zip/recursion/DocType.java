package recursion;


/**
 * A DocType is a document type.
 * 
 * @author (Kyle Evangelisto)
 * @version (Feb2021)
 */
public enum DocType {
    WORD, SPREADSHEET, SLIDES, PHOTO, JAVA;
}
