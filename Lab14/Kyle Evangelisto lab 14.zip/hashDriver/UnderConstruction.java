package hashDriver;


/**
 * A class which is under construction is in the process of
 * being developed, and may contain stubs and/or defects.
 * 
 * @author (sdb) 
 * @version (Apr 2017)
 */
public class UnderConstruction
{
    int x;
    
    public UnderConstruction (int x)
    {   this.x = x;  }
    
    public int hashCode()
    {   return x % 10;        // This is just a stub,  I'll get to this later.
    } 
}
